/** @type {import('tailwindcss').Config} */
module.exports = {
    content: ["./**/*.{html,js}"], // oder passe das an deine Struktur an
    theme: {
        extend: {},
    },
    plugins: [],
}
